<?php
/**
 * Plugin Name:       Faded Carousel Gallery for Elementor
 * Plugin URI:        https://github.com/Htechdigitalconcept/faded-carousel-gallery
 * Description:       A centered, looping carousel gallery widget for Elementor. The active photo sits in focus, neighbouring photos fade out, and a synced thumbnail strip sits underneath. Add images straight from the WordPress media library and control everything from the Elementor panel.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Requires Plugins:  elementor
 * Author:            Htech Digital Concept
 * Author URI:        https://www.htechdigitalconcept.site
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       faded-carousel-gallery
 * GitHub Plugin URI: Htechdigitalconcept/faded-carousel-gallery
 * Primary Branch:    main
 *
 * Faded Carousel Gallery for Elementor
 * Copyright (C) 2026 Htech Digital Concept
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * This plugin is not affiliated with or endorsed by Elementor Ltd.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FCG_VERSION', '1.0.0' );
define( 'FCG_FILE', __FILE__ );
define( 'FCG_URL', plugin_dir_url( __FILE__ ) );
define( 'FCG_PATH', plugin_dir_path( __FILE__ ) );
define( 'FCG_REPO_URL', 'https://github.com/Htechdigitalconcept/faded-carousel-gallery' );
define( 'FCG_AUTHOR_URL', 'https://www.htechdigitalconcept.site' );

final class FCG_Plugin {

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_filter( 'plugin_row_meta', array( $this, 'row_meta' ), 10, 2 );
	}

	public function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_elementor_notice' ) );
			return;
		}

		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_scripts' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
	}

	public function register_styles() {
		wp_register_style( 'fcg-style', FCG_URL . 'assets/fcg.css', array(), FCG_VERSION );
	}

	public function register_scripts() {
		wp_register_script( 'fcg-script', FCG_URL . 'assets/fcg.js', array( 'elementor-frontend' ), FCG_VERSION, true );
	}

	public function register_widgets( $widgets_manager ) {
		require_once FCG_PATH . 'includes/class-widget.php';
		$widgets_manager->register( new \FCG\Widget() );
	}

	/**
	 * Extra links under the plugin name on the Plugins screen.
	 */
	public function row_meta( $links, $file ) {
		if ( plugin_basename( FCG_FILE ) !== $file ) {
			return $links;
		}

		$links[] = '<a href="' . esc_url( FCG_REPO_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'GitHub', 'faded-carousel-gallery' ) . '</a>';
		$links[] = '<a href="' . esc_url( FCG_REPO_URL . '/issues' ) . '" target="_blank" rel="noopener">' . esc_html__( 'Support', 'faded-carousel-gallery' ) . '</a>';
		$links[] = '<a href="' . esc_url( FCG_AUTHOR_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'Htech Digital Concept', 'faded-carousel-gallery' ) . '</a>';

		return $links;
	}

	public function missing_elementor_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>'
			. esc_html__( 'Faded Carousel Gallery needs Elementor (3.5 or newer) to be installed and active.', 'faded-carousel-gallery' )
			. '</p></div>';
	}
}

new FCG_Plugin();
