/*!
 * Faded Carousel Gallery for Elementor
 * (c) 2026 Htech Digital Concept - https://www.htechdigitalconcept.site
 * License: GPL-2.0-or-later
 */
( function ( $ ) {
	'use strict';

	/**
	 * Create a Swiper instance using Elementor's own (lazy-loaded) Swiper.
	 * Always returns a Promise.
	 */
	function createSwiper( el, config ) {
		var Ctor = window.elementorFrontend && elementorFrontend.utils && elementorFrontend.utils.swiper;

		if ( Ctor ) {
			var inst = new Ctor( el, config );
			return inst && typeof inst.then === 'function' ? inst : Promise.resolve( inst );
		}
		if ( window.Swiper ) {
			return Promise.resolve( new window.Swiper( el, config ) );
		}
		return Promise.reject( new Error( 'Swiper is not available' ) );
	}

	function init( $scope ) {
		var root = $scope[ 0 ].querySelector( '.fcg' );
		if ( ! root ) {
			return;
		}

		var cfg = {};
		try {
			cfg = JSON.parse( root.getAttribute( 'data-fcg' ) || '{}' );
		} catch ( e ) {}

		var mainEl = root.querySelector( '.fcg-main' );
		var total = mainEl ? mainEl.querySelectorAll( '.fcg-slide' ).length : 0;
		if ( ! total ) {
			return;
		}

		var thumbs = Array.prototype.slice.call( root.querySelectorAll( '.fcg-thumb' ) );
		var track = root.querySelector( '.fcg-thumbs-track' );
		var prevBtn = root.querySelector( '.fcg-prev' );
		var nextBtn = root.querySelector( '.fcg-next' );

		var loop = !! cfg.loop && total > 3;

		var swiperCfg = {
			slidesPerView: 'auto',
			centeredSlides: true,
			spaceBetween: cfg.gap || 0,
			speed: cfg.speed || 500,
			loop: loop,
			loopedSlides: total, // Swiper 8: needed for slidesPerView "auto"
			loopAdditionalSlides: 2,
			slideToClickedSlide: !! cfg.clickToSlide,
			grabCursor: true,
			watchOverflow: true,
			keyboard: { enabled: true, onlyInViewport: true },
			autoplay: cfg.autoplay
				? {
						delay: cfg.delay || 3500,
						disableOnInteraction: false,
						pauseOnMouseEnter: !! cfg.pauseHover,
				  }
				: false,
		};

		createSwiper( mainEl, swiperCfg ).then( function ( swiper ) {
			function setActive( index ) {
				thumbs.forEach( function ( t, k ) {
					var on = k === index;
					t.classList.toggle( 'is-active', on );
					if ( on ) {
						t.setAttribute( 'aria-current', 'true' );
					} else {
						t.removeAttribute( 'aria-current' );
					}
				} );

				var t = thumbs[ index ];
				if ( t && track && track.scrollWidth > track.clientWidth ) {
					var left = t.offsetLeft - ( track.clientWidth - t.offsetWidth ) / 2;
					track.scrollTo( { left: left, behavior: 'smooth' } );
				}
			}

			function goTo( index ) {
				if ( loop ) {
					swiper.slideToLoop( index );
				} else {
					swiper.slideTo( index );
				}
			}

			swiper.on( 'slideChange', function () {
				setActive( swiper.realIndex );
			} );

			thumbs.forEach( function ( t, k ) {
				t.addEventListener( 'click', function () {
					goTo( k );
				} );
			} );

			if ( prevBtn ) {
				prevBtn.addEventListener( 'click', function () {
					swiper.slidePrev();
				} );
			}
			if ( nextBtn ) {
				nextBtn.addEventListener( 'click', function () {
					swiper.slideNext();
				} );
			}

			// Re-measure slides once images finish loading (natural-width mode).
			var timer;
			mainEl.addEventListener(
				'load',
				function () {
					clearTimeout( timer );
					timer = setTimeout( function () {
						if ( swiper && ! swiper.destroyed ) {
							swiper.update();
						}
					}, 80 );
				},
				true
			);

			setActive( swiper.realIndex || 0 );
		} );
	}

	$( window ).on( 'elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/fcg_gallery.default', init );
	} );
} )( jQuery );
