<?php
/**
 * Faded Carousel Gallery for Elementor - widget.
 *
 * @package FadedCarouselGallery
 * @author  Htech Digital Concept (https://www.htechdigitalconcept.site)
 * @license GPL-2.0-or-later
 */

namespace FCG;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Widget extends Widget_Base {

	public function get_name() {
		return 'fcg_gallery';
	}

	public function get_title() {
		return esc_html__( 'Faded Carousel Gallery', 'faded-carousel-gallery' );
	}

	public function get_icon() {
		return 'eicon-slider-album';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_custom_help_url() {
		return FCG_REPO_URL . '#readme';
	}

	public function get_keywords() {
		return array( 'gallery', 'carousel', 'slider', 'thumbnails', 'faded', 'photos' );
	}

	public function get_style_depends() {
		return array( 'fcg-style' );
	}

	public function get_script_depends() {
		return array( 'fcg-script' );
	}

	protected function register_controls() {

		/* ------------------------------------------------------------
		 * CONTENT: images
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_gallery',
			array( 'label' => esc_html__( 'Images', 'faded-carousel-gallery' ) )
		);

		$this->add_control(
			'gallery',
			array(
				'label'      => esc_html__( 'Add Images', 'faded-carousel-gallery' ),
				'type'       => Controls_Manager::GALLERY,
				'show_label' => false,
				'default'    => array(),
			)
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'    => 'slide_image',
				'default' => 'large',
			)
		);

		$this->end_controls_section();

		/* ------------------------------------------------------------
		 * CONTENT: layout
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_layout',
			array( 'label' => esc_html__( 'Layout', 'faded-carousel-gallery' ) )
		);

		$this->add_control(
			'slide_mode',
			array(
				'label'   => esc_html__( 'Image Shape', 'faded-carousel-gallery' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'natural',
				'options' => array(
					'natural' => esc_html__( 'Natural (each photo keeps its own shape)', 'faded-carousel-gallery' ),
					'fixed'   => esc_html__( 'Uniform (all photos cropped to same size)', 'faded-carousel-gallery' ),
				),
			)
		);

		$this->add_responsive_control(
			'slide_height',
			array(
				'label'           => esc_html__( 'Image Height', 'faded-carousel-gallery' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => array( 'px', 'vh' ),
				'range'           => array(
					'px' => array( 'min' => 100, 'max' => 1000 ),
					'vh' => array( 'min' => 10, 'max' => 100 ),
				),
				'default'         => array( 'size' => 400, 'unit' => 'px' ),
				'tablet_default'  => array( 'size' => 340, 'unit' => 'px' ),
				'mobile_default'  => array( 'size' => 260, 'unit' => 'px' ),
				'selectors'       => array(
					'{{WRAPPER}} .fcg' => '--fcg-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'slide_width',
			array(
				'label'           => esc_html__( 'Image Width', 'faded-carousel-gallery' ),
				'type'            => Controls_Manager::SLIDER,
				'size_units'      => array( 'px', 'vw' ),
				'range'           => array(
					'px' => array( 'min' => 100, 'max' => 1400 ),
					'vw' => array( 'min' => 10, 'max' => 100 ),
				),
				'default'         => array( 'size' => 600, 'unit' => 'px' ),
				'tablet_default'  => array( 'size' => 480, 'unit' => 'px' ),
				'mobile_default'  => array( 'size' => 280, 'unit' => 'px' ),
				'condition'       => array( 'slide_mode' => 'fixed' ),
				'selectors'       => array(
					'{{WRAPPER}} .fcg' => '--fcg-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'object_fit',
			array(
				'label'     => esc_html__( 'Crop Style', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cover',
				'options'   => array(
					'cover'   => esc_html__( 'Fill (crop edges)', 'faded-carousel-gallery' ),
					'contain' => esc_html__( 'Fit (show whole photo)', 'faded-carousel-gallery' ),
				),
				'condition' => array( 'slide_mode' => 'fixed' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-fit: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'gap',
			array(
				'label'   => esc_html__( 'Space Between Images', 'faded-carousel-gallery' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array( 'px' => array( 'min' => 0, 'max' => 100 ) ),
				'default' => array( 'size' => 10, 'unit' => 'px' ),
			)
		);

		$this->add_control(
			'show_thumbs',
			array(
				'label'        => esc_html__( 'Show Thumbnails', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			)
		);

		$this->add_control(
			'show_arrows',
			array(
				'label'        => esc_html__( 'Show Arrows', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		/* ------------------------------------------------------------
		 * CONTENT: behaviour
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_behaviour',
			array( 'label' => esc_html__( 'Behaviour', 'faded-carousel-gallery' ) )
		);

		$this->add_control(
			'loop',
			array(
				'label'        => esc_html__( 'Infinite Loop', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'click_to_slide',
			array(
				'label'        => esc_html__( 'Click a Faded Image to Bring It to Centre', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Slide Speed (ms)', 'faded-carousel-gallery' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 3000,
				'step'    => 50,
				'default' => 500,
			)
		);

		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'separator'    => 'before',
			)
		);

		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1000,
				'max'       => 15000,
				'step'      => 100,
				'default'   => 3500,
				'condition' => array( 'autoplay' => 'yes' ),
			)
		);

		$this->add_control(
			'pause_on_hover',
			array(
				'label'        => esc_html__( 'Pause on Hover', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array( 'autoplay' => 'yes' ),
			)
		);

		$this->end_controls_section();

		/* ------------------------------------------------------------
		 * STYLE: slides
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_slides',
			array(
				'label' => esc_html__( 'Images', 'faded-carousel-gallery' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'inactive_opacity',
			array(
				'label'     => esc_html__( 'Faded Image Opacity', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
				'default'   => array( 'size' => 0.3 ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-fade: {{SIZE}};',
				),
			)
		);

		$this->add_control(
			'fade_duration',
			array(
				'label'     => esc_html__( 'Fade Duration (ms)', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 1500, 'step' => 50 ) ),
				'default'   => array( 'size' => 400 ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-fade-time: {{SIZE}}ms;',
				),
			)
		);

		$this->add_control(
			'slide_radius',
			array(
				'label'     => esc_html__( 'Corner Radius', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
				'default'   => array( 'size' => 0, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'edge_mask',
			array(
				'label'        => esc_html__( 'Soft Gradient on Left/Right Edges', 'faded-carousel-gallery' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'separator'    => 'before',
			)
		);

		$this->add_control(
			'mask_width',
			array(
				'label'     => esc_html__( 'Gradient Width', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'     => array( '%' => array( 'min' => 2, 'max' => 40 ) ),
				'default'   => array( 'size' => 12, 'unit' => '%' ),
				'condition' => array( 'edge_mask' => 'yes' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-mask: {{SIZE}}%;',
				),
			)
		);

		$this->end_controls_section();

		/* ------------------------------------------------------------
		 * STYLE: thumbnails
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_thumbs',
			array(
				'label'     => esc_html__( 'Thumbnails', 'faded-carousel-gallery' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_thumbs' => 'yes' ),
			)
		);

		$this->add_control(
			'thumb_size',
			array(
				'label'     => esc_html__( 'Thumbnail Size', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 40, 'max' => 130 ) ),
				'default'   => array( 'size' => 70, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-thumb: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'thumb_gap',
			array(
				'label'     => esc_html__( 'Space Between Thumbnails', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'default'   => array( 'size' => 8, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-thumb-gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'thumb_top',
			array(
				'label'     => esc_html__( 'Space Above Thumbnails', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'default'   => array( 'size' => 12, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-thumb-top: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'thumb_radius',
			array(
				'label'     => esc_html__( 'Thumbnail Corner Radius', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 65 ) ),
				'default'   => array( 'size' => 0, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-thumb-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'thumb_opacity',
			array(
				'label'     => esc_html__( 'Inactive Thumbnail Opacity', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ) ),
				'default'   => array( 'size' => 0.55 ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-thumb-opacity: {{SIZE}};',
				),
			)
		);

		$this->add_control(
			'thumb_active_color',
			array(
				'label'     => esc_html__( 'Active Thumbnail Border Colour', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-active: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'thumb_active_width',
			array(
				'label'     => esc_html__( 'Active Thumbnail Border Width', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 8 ) ),
				'default'   => array( 'size' => 2, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-active-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		/* ------------------------------------------------------------
		 * STYLE: arrows
		 * ---------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_arrows',
			array(
				'label'     => esc_html__( 'Arrows', 'faded-carousel-gallery' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_arrows' => 'yes' ),
			)
		);

		$this->add_control(
			'arrow_color',
			array(
				'label'     => esc_html__( 'Icon Colour', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-arrow-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'arrow_bg',
			array(
				'label'     => esc_html__( 'Background Colour', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0,0,0,0.55)',
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-arrow-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'arrow_size',
			array(
				'label'     => esc_html__( 'Button Size', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 28, 'max' => 90 ) ),
				'default'   => array( 'size' => 44, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-arrow-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'arrow_inset',
			array(
				'label'     => esc_html__( 'Distance From Edge', 'faded-carousel-gallery' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'default'   => array( 'size' => 16, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .fcg' => '--fcg-arrow-inset: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();

		$gallery = ! empty( $s['gallery'] ) ? $s['gallery'] : array();

		if ( empty( $gallery ) ) {
			if ( Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="fcg-empty">' . esc_html__( 'Faded Carousel Gallery: click "Add Images" in the left panel to choose photos from your media library.', 'faded-carousel-gallery' ) . '</div>';
			}
			return;
		}

		$config = array(
			'loop'        => 'yes' === $s['loop'],
			'speed'       => (int) $s['speed'],
			'gap'         => isset( $s['gap']['size'] ) ? (int) $s['gap']['size'] : 10,
			'clickToSlide' => 'yes' === $s['click_to_slide'],
			'autoplay'    => 'yes' === $s['autoplay'] && ! Plugin::$instance->editor->is_edit_mode(),
			'delay'       => (int) $s['autoplay_delay'],
			'pauseHover'  => 'yes' === $s['pause_on_hover'],
		);

		$this->add_render_attribute( 'fcg', 'class', array( 'fcg', 'fcg--' . $s['slide_mode'] ) );
		if ( 'yes' === $s['edge_mask'] ) {
			$this->add_render_attribute( 'fcg', 'class', 'fcg--mask' );
		}
		$this->add_render_attribute( 'fcg', 'data-fcg', wp_json_encode( $config ) );

		$arrow_prev = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M15.4 5.4 14 4l-8 8 8 8 1.4-1.4L8.8 12z"/></svg>';
		$arrow_next = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M8.6 5.4 10 4l8 8-8 8-1.4-1.4 6.6-6.6z"/></svg>';
		?>
		<div <?php $this->print_render_attribute_string( 'fcg' ); ?>>
			<div class="fcg-stage">
				<div class="fcg-main swiper">
					<div class="swiper-wrapper">
						<?php
						foreach ( $gallery as $item ) {
							$img_settings          = $s;
							$img_settings['image'] = array(
								'id'  => isset( $item['id'] ) ? $item['id'] : '',
								'url' => isset( $item['url'] ) ? $item['url'] : '',
							);
							$img_html = Group_Control_Image_Size::get_attachment_image_html( $img_settings, 'slide_image', 'image' );
							if ( empty( $img_html ) ) {
								continue;
							}
							echo '<div class="swiper-slide fcg-slide">' . $img_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
						}
						?>
					</div>
				</div>

				<?php if ( 'yes' === $s['show_arrows'] ) : ?>
					<button type="button" class="fcg-arrow fcg-prev" aria-label="<?php echo esc_attr__( 'Previous image', 'faded-carousel-gallery' ); ?>"><?php echo $arrow_prev; // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
					<button type="button" class="fcg-arrow fcg-next" aria-label="<?php echo esc_attr__( 'Next image', 'faded-carousel-gallery' ); ?>"><?php echo $arrow_next; // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
				<?php endif; ?>
			</div>

			<?php if ( 'yes' === $s['show_thumbs'] ) : ?>
				<div class="fcg-thumbs">
					<div class="fcg-thumbs-track">
						<?php
						foreach ( $gallery as $i => $item ) {
							if ( ! empty( $item['id'] ) ) {
								$thumb = wp_get_attachment_image( $item['id'], 'thumbnail', false, array( 'alt' => '' ) );
							} else {
								$thumb = '<img src="' . esc_url( $item['url'] ) . '" alt="">';
							}
							/* translators: %d: image number */
							$label = sprintf( esc_attr__( 'Show image %d', 'faded-carousel-gallery' ), $i + 1 );
							echo '<button type="button" class="fcg-thumb" aria-label="' . $label . '">' . $thumb . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
						}
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
