# Contributing

Thanks for your interest in improving **Faded Carousel Gallery for Elementor**.

## Reporting a bug
Open an [issue](https://github.com/Htechdigitalconcept/faded-carousel-gallery/issues) and include:
- WordPress, PHP and Elementor versions
- Your theme (and whether the bug happens on a default theme)
- Steps to reproduce, and a screenshot if it is visual
- Any message from the browser console

## Suggesting a feature
Open an issue describing what you want to achieve and why. Screenshots or examples help.

## Sending a pull request
1. Fork the repository and create a branch from `main`.
2. Keep changes focused, and follow the [WordPress coding standards](https://developer.wordpress.org/coding-standards/).
3. Test the widget in the Elementor editor and on the front end (desktop, tablet and mobile).
4. Update `CHANGELOG.md` and, if behaviour changes, `README.md` and `readme.txt`.
5. Open the pull request and describe what changed and how you tested it.

By contributing, you agree that your contribution is licensed under GPL-2.0-or-later, the same license as this project.
