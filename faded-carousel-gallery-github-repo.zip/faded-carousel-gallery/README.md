<div align="center">

# Faded Carousel Gallery for Elementor

**A centered, looping gallery carousel for Elementor. The active photo sits in focus, its neighbours fade back, and a synced thumbnail strip keeps everything easy to browse.**

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-GPL--2.0--or--later-green)
![WordPress](https://img.shields.io/badge/WordPress-5.8%2B-21759b)
![Elementor](https://img.shields.io/badge/Elementor-3.5%2B-92003b)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-777bb4)

Built by [**Htech Digital Concept**](https://www.htechdigitalconcept.site)

</div>

---

## Why this plugin

Many gallery widgets force you to edit image links in code or settle for a plain slider. **Faded Carousel Gallery** gives you a polished, modern look and a normal WordPress workflow: click **Add Images**, pick photos from the media library (or upload from your computer), drag to reorder, and style everything from the Elementor panel.

## Features

- **Centered focus slide** with faded neighbouring images (fade level and speed adjustable)
- **Synced thumbnail strip** that scrolls to keep the active thumbnail visible
- **Natural or Uniform shapes**: each photo keeps its own proportions, or all photos are cropped to one size
- **Infinite loop, touch swipe, mouse drag and keyboard arrows**
- **Click a faded image** to bring it to the centre
- **Optional autoplay** with delay and pause-on-hover
- **Optional soft gradient** on the left and right edges
- **Responsive controls** with separate image height and width for desktop, tablet and mobile
- **Full styling** from the Elementor panel: opacity, corner radius, thumbnail size and spacing, active border, arrow colours and size
- **Image resolution selector** to keep galleries fast
- **Accessible**: labelled buttons, keyboard support, respects "reduce motion"
- **Lightweight**: reuses the Swiper library that Elementor already loads
- Works with the **free version of Elementor** and themes such as Blocksy

## Requirements

| Requirement | Version |
|---|---|
| WordPress | 5.8 or newer |
| PHP | 7.4 or newer |
| Elementor (free is enough) | 3.5 or newer |

## Installation

### Option 1: Upload the zip (recommended)
1. Download `faded-carousel-gallery-1.0.0.zip` from the [Releases](https://github.com/Htechdigitalconcept/faded-carousel-gallery/releases) page.
   Use the release asset, not GitHub's automatic "Source code (zip)", which has a different folder name.
2. In WordPress, go to **Plugins → Add New → Upload Plugin**, choose the zip and click **Install Now**.
3. Click **Activate**.

### Option 2: Install with Git Updater
The plugin includes the headers used by the [Git Updater](https://git-updater.com/) plugin, so you can install and update it directly from this repository: `Htechdigitalconcept/faded-carousel-gallery`.

### Option 3: Manual / FTP
Upload the `faded-carousel-gallery` folder to `/wp-content/plugins/` and activate it from the **Plugins** screen.

## Usage

1. Open a page with Elementor.
2. Search for **Faded Carousel Gallery** and drag the widget onto your page.
3. Click **Add Images**, choose your photos, and drag to reorder.
4. Adjust the **Layout**, **Behaviour** and **Style** settings.

## Settings reference

### Content tab

| Section | Setting | What it does |
|---|---|---|
| Images | Add Images | Choose photos from the media library or upload new ones |
| Images | Image Resolution | Which size of each photo to load |
| Layout | Image Shape | *Natural* keeps each photo's proportions; *Uniform* crops all to the same size |
| Layout | Image Height | Height of the slides, set per device |
| Layout | Image Width | Slide width in Uniform mode, set per device |
| Layout | Crop Style | *Fill* (crop edges) or *Fit* (show the whole photo) in Uniform mode |
| Layout | Space Between Images | Gap between slides |
| Layout | Show Thumbnails / Show Arrows | Turn the thumbnail strip and arrows on or off |
| Behaviour | Infinite Loop | Endless looping |
| Behaviour | Click a Faded Image to Bring It to Centre | Click a side image to focus it |
| Behaviour | Slide Speed | Transition time in milliseconds |
| Behaviour | Autoplay, Delay, Pause on Hover | Automatic sliding options |

### Style tab

| Section | Setting |
|---|---|
| Images | Faded Image Opacity, Fade Duration, Corner Radius, Soft Gradient on Left/Right Edges and its width |
| Thumbnails | Size, spacing, space above, corner radius, inactive opacity, active border colour and width |
| Arrows | Icon colour, background colour, button size, distance from the edge |

## Tips

- To hide the neighbouring images completely, set **Faded Image Opacity** to `0`.
- For a clean, uniform grid look, use **Image Shape → Uniform** with **Crop Style → Fill**.
- If your photos are very large, choose a smaller **Image Resolution** to speed up the page.
- Autoplay is switched off inside the Elementor editor so it does not distract you while designing. It runs on the live page.

## FAQ

**Do I need Elementor Pro?**
No. The free version of Elementor is enough.

**The gallery looks unstyled or does not slide.**
Clear your site and browser caches. If you use an optimisation plugin, exclude `assets/fcg.js` and `assets/fcg.css` from minification, combining and deferral.

**Can I use more than one gallery on a page?**
Yes. Each widget works independently.

**Does it work on mobile?**
Yes. It supports touch swiping and has separate size settings for tablet and mobile.

## Troubleshooting

| Problem | Try this |
|---|---|
| Widget is missing in Elementor | Confirm Elementor 3.5+ is active, then re-save permalinks and clear caches |
| Images are cut off or wrong size | Check **Image Shape**, **Image Height** and **Image Width** for each device |
| A gap appears around the gallery | Check Margin and Padding on the container holding the widget, and Blocksy's content spacing |
| Slider jumps or mis-centres on first load | Clear caches, and make sure lazy-loading or optimisation plugins are not delaying the scripts |

## Contributing

Bug reports, ideas and pull requests are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) first.

## Support and contact

- **Issues and feature requests:** [GitHub Issues](https://github.com/Htechdigitalconcept/faded-carousel-gallery/issues)
- **Website:** [www.htechdigitalconcept.site](https://www.htechdigitalconcept.site)
- **Email:** [hablad19@gmail.com](mailto:hablad19@gmail.com)
- **LinkedIn:** [in/htechdigitalconcept](https://www.linkedin.com/in/htechdigitalconcept)
- **GitHub:** [@Htechdigitalconcept](https://github.com/Htechdigitalconcept)

## Credits

- Carousel engine: [Swiper](https://swiperjs.com/) (MIT), loaded through Elementor.
- Built for [Elementor](https://elementor.com/). This plugin is not affiliated with or endorsed by Elementor Ltd.

## License

Released under the **GNU General Public License v2 or later**. See [LICENSE](LICENSE) for the full text.

---

<div align="center">

**Made by [Htech Digital Concept](https://www.htechdigitalconcept.site)** · Global

If this plugin helps you, consider giving the repository a star on GitHub.

</div>
