---
name: Bug report
about: Something is not working as expected
title: "[Bug] "
labels: bug
---

**What happened?**
A clear description of the problem.

**Steps to reproduce**
1.
2.
3.

**Expected behaviour**

**Screenshots**

**Environment**
- WordPress version:
- PHP version:
- Elementor version:
- Theme:
- Plugin version:
- Browser / device:
- Caching or optimisation plugins:
