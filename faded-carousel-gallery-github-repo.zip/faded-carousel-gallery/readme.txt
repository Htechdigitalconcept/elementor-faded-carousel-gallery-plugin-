=== Faded Carousel Gallery for Elementor ===
Contributors: htechdigitalconcept
Tags: elementor, gallery, carousel, slider, thumbnails
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A centered, looping Elementor gallery carousel with faded neighbouring images and a synced thumbnail strip. Add photos from your media library.

== Description ==

**Faded Carousel Gallery for Elementor** adds a new widget to Elementor: a beautiful, centered photo carousel where the active image is in sharp focus, the images on either side fade back, and a thumbnail strip underneath stays in sync with the main slider.

You add photos the normal WordPress way: click **Add Images**, choose from your media library or upload from your computer, and drag to reorder. No code, no image links to edit.

= Features =

* Centered focus slide with faded neighbours (fade level is adjustable)
* Synced thumbnail strip that scrolls to keep the active thumbnail in view
* Natural mode (each photo keeps its own shape) or Uniform mode (all photos cropped to the same size)
* Infinite loop, swipe and drag, keyboard arrows, click-a-side-image-to-centre
* Optional autoplay with adjustable delay and pause on hover
* Optional soft gradient on the left and right edges
* Responsive controls: separate image height and width for desktop, tablet and mobile
* Full styling controls in the Elementor panel: opacity, fade speed, corner radius, thumbnail size, spacing, active border, arrow colours and size
* Choose which image resolution loads, so galleries stay fast
* Accessible: labelled buttons, keyboard support, and respects "reduce motion" settings
* Uses the Swiper library that Elementor already loads, so it adds almost no weight
* Works with the free version of Elementor and with themes such as Blocksy

= Requirements =

* Elementor 3.5 or newer (free version is enough)
* WordPress 5.8 or newer
* PHP 7.4 or newer

= How to use =

1. Edit a page with Elementor.
2. Search for **Faded Carousel Gallery** and drag it onto the page.
3. Click **Add Images** and choose your photos.
4. Adjust the Layout, Behaviour and Style settings to taste.

= Credits and disclaimer =

Built and maintained by [Htech Digital Concept](https://www.htechdigitalconcept.site). Source code and issue tracker: [GitHub](https://github.com/Htechdigitalconcept/faded-carousel-gallery). This plugin is not affiliated with or endorsed by Elementor Ltd.

== Installation ==

1. Go to **Plugins > Add New > Upload Plugin**, choose the plugin zip, and click **Install Now**.
2. Activate the plugin.
3. Make sure Elementor is installed and active.
4. Open a page in Elementor and search for **Faded Carousel Gallery**.

Or upload the `faded-carousel-gallery` folder to `/wp-content/plugins/` by FTP and activate it from the Plugins screen.

== Frequently Asked Questions ==

= Do I need Elementor Pro? =

No. The free version of Elementor is enough.

= How do I add or change images? =

Select the widget, click the gallery in the left panel, and use the media library to add, remove or reorder photos.

= Can I show only one image at a time with no faded neighbours? =

Set **Faded Image Opacity** to 0 in the Style tab to hide the neighbouring images completely.

= My photos look different heights in the carousel. =

Use **Image Shape > Uniform** to crop every photo to the same size, or keep **Natural** to let each photo keep its own proportions at a shared height.

= The gallery looks unstyled or does not slide. =

Clear your site and browser cache, then check that your optimisation or caching plugin is not deferring or minifying `fcg.js` and `fcg.css`. Exclude them if it is.

= Does it work on mobile? =

Yes. It supports touch swiping and has separate size controls for tablet and mobile.

= Where do I report a bug or ask for a feature? =

Open an issue on [GitHub](https://github.com/Htechdigitalconcept/faded-carousel-gallery/issues) or contact Htech Digital Concept through [www.htechdigitalconcept.site](https://www.htechdigitalconcept.site).

== Changelog ==

= 1.0.0 =
* Initial public release.
