# Changelog

All notable changes to this project are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project uses [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-11-11

### Added
- Initial public release.
- Elementor widget **Faded Carousel Gallery** with a media-library gallery picker.
- Centered focus slide with adjustable faded neighbours and fade duration.
- Synced thumbnail strip with auto-centering of the active thumbnail.
- Natural and Uniform (cropped) image shapes, with responsive height and width.
- Infinite loop, swipe, keyboard navigation, click-to-centre, optional autoplay.
- Optional soft gradient on the left and right edges.
- Style controls for images, thumbnails and arrows.
- Image resolution selector.
- Plugin row links to GitHub, support and author site.
