---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
---

**What would you like to achieve?**

**Why is it useful?**

**Examples or screenshots (optional)**
